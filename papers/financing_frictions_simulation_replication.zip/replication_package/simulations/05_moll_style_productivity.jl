# Slide 5: Moll-Style Stochastic Productivity with Collateral Constraints
# AR(1) z shocks + collateral constraint. Self-financing speed depends on z persistence.
# Two sub-cases: high rho_z vs low rho_z.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Random
using Distributions

# Per-script overrides
const RHO_Z_HIGH = 0.95
const RHO_Z_LOW  = 0.50

# Equalize unconditional variance of log(z) across persistence levels.
# Unconditional var = sigma^2 / (1 - rho^2). Fix target SD(log z) = 0.50.
const VAR_LOGZ_TARGET = 0.25
const SIGMA_Z_HIGH = sqrt(VAR_LOGZ_TARGET * (1 - RHO_Z_HIGH^2))
const SIGMA_Z_LOW  = sqrt(VAR_LOGZ_TARGET * (1 - RHO_Z_LOW^2))
const Z_STATIONARY_DIST = LogNormal(log(Z_BAR), sqrt(VAR_LOGZ_TARGET))

# ── Simulate panels under high and low persistence ──────────────────

T = 150

panel_high = simulate_panel(
    N=N_FIRMS, T=T,
    z_process=:ar1, ρz=RHO_Z_HIGH, σz=SIGMA_Z_HIGH,
    zbar=Z_BAR, z_dist=Z_STATIONARY_DIST,
    seed=SEED,
)
panel_low = simulate_panel(
    N=N_FIRMS, T=T,
    z_process=:ar1, ρz=RHO_Z_LOW, σz=SIGMA_Z_LOW,
    zbar=Z_BAR, z_dist=Z_STATIONARY_DIST,
    seed=SEED,
)

# Deterministic baseline for reference
panel_det = simulate_panel(
    N=N_FIRMS, T=T,
    z_process=:deterministic, z_dist=Z_STATIONARY_DIST,
    seed=SEED,
)

var_high = var_log_mrpk_series(panel_high)
var_low  = var_log_mrpk_series(panel_low)
var_det  = var_log_mrpk_series(panel_det)

# ── Plot ────────────────────────────────────────────────────────────

fig = Figure(
    size=(FIGURE_WIDTH, FIGURE_HEIGHT),
    backgroundcolor=:white,
    fontsize=13,
    font=FONT,
)

# Panel A: Var(log MRPK) over time for all three cases
ax_var = Axis(fig[1, 1];
    xlabel="Period",
    ylabel="Var(log MRPK)",
    rightspinevisible=false,
    topspinevisible=false,
    xgridvisible=false,
    ygridcolor=GRID_GRAY,
    xlabelcolor=DARK,
    ylabelcolor=DARK,
    xticklabelcolor=DARK,
    yticklabelcolor=DARK,
)

l_det = lines!(ax_var, 1:T, var_det;
    color=COLOR_UNCONSTRAINED, linewidth=2, linestyle=:dash)
l_low = lines!(ax_var, 1:T, var_low;
    color=COLOR_THIRD, linewidth=2)
l_high = lines!(ax_var, 1:T, var_high;
    color=COLOR_CONSTRAINED, linewidth=2.5)

# Panel B: Scatter of (log z, log a) in steady state (last period) — high rho case
ax_scatter = Axis(fig[1, 2];
    xlabel="log(z)",
    ylabel="log(a)",
    rightspinevisible=false,
    topspinevisible=false,
    xgridvisible=false,
    ygridcolor=GRID_GRAY,
    xlabelcolor=DARK,
    ylabelcolor=DARK,
    xticklabelcolor=DARK,
    yticklabelcolor=DARK,
)

logz_ss = log.(panel_high.z[:, T])
loga_ss = log.(max.(panel_high.a[:, T], 1e-10))

scatter!(ax_scatter, logz_ss, loga_ss;
    color=(COLOR_CONSTRAINED, 0.4), markersize=5)

# Fitted relationship between persistent productivity and accumulated net worth.
xbar = mean(logz_ss)
ybar = mean(loga_ss)
β_fit = sum((logz_ss .- xbar) .* (loga_ss .- ybar)) / sum((logz_ss .- xbar) .^ 2)
α_fit = ybar - β_fit * xbar
zrange = range(extrema(logz_ss)..., length=50)
lines!(ax_scatter, zrange, α_fit .+ β_fit .* zrange;
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

Legend(fig[2, 1:2],
    [l_det, l_low, l_high],
    ["Deterministic", "Low persistence (ρ = $(RHO_Z_LOW))", "High persistence (ρ = $(RHO_Z_HIGH))"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

save_figure(fig, "fig_05_moll_productivity.pdf")
