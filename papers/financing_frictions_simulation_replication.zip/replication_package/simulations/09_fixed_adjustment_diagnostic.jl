# Diagnostic: fixed adjustment cost only (Cooper-Haltiwanger lumpy investment).
# Same productivity opportunity as script 08, but with a pure fixed cost.
# Generates discrete bursts and stale-K intervals; MRPK departs from user
# cost throughout the inaction region.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))

const PSI_FIXED = 0.35           # lump-sum cost coefficient, scaled by k_prev
const VARTHETA = 0.05            # threshold below which adjustment is "passive"
const OPPORTUNITY_START = 16
const OPPORTUNITY_END = 42
const Z_OPPORTUNITY_MULTIPLIER = 1.25

function productivity_path(T)
    z = fill(Z_BAR, T)
    z[OPPORTUNITY_START:OPPORTUNITY_END] .= Z_BAR * Z_OPPORTUNITY_MULTIPLIER
    return z
end

# Firm with pure fixed cost ψ·1{|i/k_prev| > ϑ}·k_prev.
# Each period it chooses between:
#   (i)  Passive: k_t = (1-δ)·k_{t-1}, no fixed cost paid.
#   (ii) Active: k_t = k*(z_t) (optimal static target), pay ψ·k_{t-1}.
function choose_k_with_fixed_cost(z, k_prev, α, r, δk, ψ)
    k_passive = (1 - δk) * k_prev
    value_passive = production(z, k_passive, α) - (r + δk) * k_passive

    kfb = k_star(z, r, α, δk)
    value_active = production(z, kfb, α) - (r + δk) * kfb - ψ * k_prev

    return value_active > value_passive ? kfb : k_passive
end

T = 80
z_path = productivity_path(T)
kstar_path = [k_star(z_path[t], R, ALPHA, DELTA_K) for t in 1:T]

k_fixed = zeros(T)
k_fixed[1] = kstar_path[1]
for t in 2:T
    k_fixed[t] = choose_k_with_fixed_cost(
        z_path[t], k_fixed[t - 1], ALPHA, R, DELTA_K, PSI_FIXED
    )
end

mrpk_star = fill(user_cost(R, DELTA_K), T)
mrpk_fixed = [mrpk(z_path[t], k_fixed[t], ALPHA) for t in 1:T]

fig, ax_k, ax_mrpk = create_two_panel_figure()

l_star = lines!(ax_k, 1:T, kstar_path;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
l_fixed = lines!(ax_k, 1:T, k_fixed;
    color=COLOR_CONSTRAINED, linewidth=2)

vspan!(ax_k, OPPORTUNITY_START, OPPORTUNITY_END;
    color=(VIRIDIS.yellow, 0.15))
vspan!(ax_mrpk, OPPORTUNITY_START, OPPORTUNITY_END;
    color=(VIRIDIS.yellow, 0.15))

lines!(ax_mrpk, 1:T, mrpk_star;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
lines!(ax_mrpk, 1:T, mrpk_fixed;
    color=COLOR_CONSTRAINED, linewidth=2)
hlines!(ax_mrpk, [user_cost(R, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

ax_k.ylabel = "Capital (K)"
ax_mrpk.ylabel = "MRPK"

Legend(fig[2, 1:2],
    [l_star, l_fixed],
    ["No adjustment cost (K*)", "Fixed only (ψ = $(PSI_FIXED))"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

fig_path = save_figure(fig, "fig_08b_fixed_only.pdf")
