# Diagnostic: convex adjustment costs without a financing constraint.
# This red-herring figure uses a controlled temporary productivity opportunity.
# It shows that adjustment costs can move MRPK even when collateral never binds.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))

const PHI_CONVEX = 0.30
const OPPORTUNITY_START = 16
const OPPORTUNITY_END = 42
const Z_OPPORTUNITY_MULTIPLIER = 1.25

function productivity_path(T)
    z = fill(Z_BAR, T)
    z[OPPORTUNITY_START:OPPORTUNITY_END] .= Z_BAR * Z_OPPORTUNITY_MULTIPLIER
    return z
end

function convex_adjustment_cost(k, k_prev, δk, φ)
    k_base = max(k_prev, 0.10)
    i = k - k_prev
    return φ * (i / k_base)^2 * k_base
end

function choose_k_with_convex_cost(z, k_prev, α, r, δk, φ; n_grid=700)
    kfb = k_star(z, r, α, δk)
    upper = max(2.0 * kfb, 1.8 * k_prev, 0.25)
    lower = max(0.01, 0.03 * min(kfb, max(k_prev, 0.10)))
    grid = range(lower, upper, length=n_grid)

    best_k = first(grid)
    best_value = -Inf
    for k in grid
        value = production(z, k, α) - (r + δk) * k - convex_adjustment_cost(k, k_prev, δk, φ)
        if value > best_value
            best_value = value
            best_k = k
        end
    end
    return best_k
end

T = 80
z_path = productivity_path(T)
kstar_path = [k_star(z_path[t], R, ALPHA, DELTA_K) for t in 1:T]

k_convex = zeros(T)
k_convex[1] = kstar_path[1]
for t in 2:T
    k_convex[t] = choose_k_with_convex_cost(
        z_path[t], k_convex[t - 1], ALPHA, R, DELTA_K, PHI_CONVEX
    )
end

mrpk_star = fill(user_cost(R, DELTA_K), T)
mrpk_convex = [mrpk(z_path[t], k_convex[t], ALPHA) for t in 1:T]

fig, ax_k, ax_mrpk = create_two_panel_figure()

l_star = lines!(ax_k, 1:T, kstar_path;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
l_convex = lines!(ax_k, 1:T, k_convex;
    color=COLOR_CONSTRAINED, linewidth=2)

vspan!(ax_k, OPPORTUNITY_START, OPPORTUNITY_END;
    color=(VIRIDIS.yellow, 0.15))
vspan!(ax_mrpk, OPPORTUNITY_START, OPPORTUNITY_END;
    color=(VIRIDIS.yellow, 0.15))

lines!(ax_mrpk, 1:T, mrpk_star;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
lines!(ax_mrpk, 1:T, mrpk_convex;
    color=COLOR_CONSTRAINED, linewidth=2)
hlines!(ax_mrpk, [user_cost(R, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

ax_k.ylabel = "Capital (K)"
ax_mrpk.ylabel = "MRPK"

Legend(fig[2, 1:2],
    [l_star, l_convex],
    ["No adjustment cost (K*)", "Convex only (φ = $(PHI_CONVEX))"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

fig_path = save_figure(fig, "fig_08a_convex_only.pdf")
