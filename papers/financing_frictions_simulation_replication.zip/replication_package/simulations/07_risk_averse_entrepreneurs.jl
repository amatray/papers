# Slide 7: Risk-Averse Constrained Entrepreneurs (BMSS-style)
# Risk-averse entrepreneurs can't diversify. Underinvest even with high expected returns.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Random, Distributions

# ── Risk-neutral vs risk-averse capital choice ──────────────────────

# Under risk neutrality: k = min(k*, λ a)  (Moll/BKS form)
# Under risk aversion (CRRA): entrepreneur maximizes expected utility of
# next-period wealth, using the same savings rule as the dynamic model.
# With risky output: y = z * k^alpha, z ~ LogNormal, entrepreneur bears all risk
# Risk-averse entrepreneur invests less than risk-neutral because of undiversifiable risk

const SIGMA_Z_RA = 0.40
const GAMMA_RA_LOCAL = 5.0

function expected_utility_crra(k, a, z_draws, α, r, δk, γ, s)
    u_sum = 0.0
    for z in z_draws
        profit = z * k^α - (r + δk) * k
        wealth_next = s * ((1 + r) * a + profit)
        wealth_next = max(wealth_next, 1e-10)
        if γ == 1.0
            u_sum += log(wealth_next)
        else
            u_sum += wealth_next^(1 - γ) / (1 - γ)
        end
    end
    return u_sum / length(z_draws)
end

function optimal_k_risk_averse(a, z_mean, α, r, δk, γ, λ, s; n_grid=500, n_draws=100000, rng=Random.default_rng())
    kmax = constrained_k(a, λ)
    k_grid = range(0.01, kmax, length=n_grid)

    z_dist = LogNormal(log(z_mean) - 0.5 * SIGMA_Z_RA^2, SIGMA_Z_RA)
    z_draws = rand(rng, z_dist, n_draws)

    best_k = k_grid[1]
    best_u = -Inf
    for k in k_grid
        u = expected_utility_crra(k, a, z_draws, α, r, δk, γ, s)
        if u > best_u
            best_u = u
            best_k = k
        end
    end
    return best_k
end

# ── Compute capital choices over a grid of net worth ────────────────

rng = MersenneTwister(SEED)
z_mean = Z_BAR
n_a = 40
a_grid = range(0.20 * A_UNCONSTRAINED, 2.20 * A_UNCONSTRAINED, length=n_a)

k_risk_neutral = [actual_k(z_mean, a, R, ALPHA, LAMBDA_LEV, DELTA_K) for a in a_grid]
k_risk_averse  = [optimal_k_risk_averse(a, z_mean, ALPHA, R, DELTA_K, GAMMA_RA_LOCAL, LAMBDA_LEV, SAVINGS_RATE;
                    rng=MersenneTwister(SEED + i)) for (i, a) in enumerate(a_grid)]

kfb = k_star(z_mean, R, ALPHA, DELTA_K)
mrpk_neutral = [mrpk(z_mean, k, ALPHA) for k in k_risk_neutral]
mrpk_averse  = [mrpk(z_mean, k, ALPHA) for k in k_risk_averse]

# ── Plot ────────────────────────────────────────────────────────────

fig, ax_k, ax_mrpk = create_two_panel_figure()

ax_k.xlabel = "Net worth (a)"
ax_mrpk.xlabel = "Net worth (a)"

l_fb = hlines!(ax_k, [kfb];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)
l_rn = lines!(ax_k, collect(a_grid), k_risk_neutral;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
l_ra = lines!(ax_k, collect(a_grid), k_risk_averse;
    color=COLOR_CONSTRAINED, linewidth=2)

hlines!(ax_mrpk, [user_cost(R, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)
lines!(ax_mrpk, collect(a_grid), mrpk_neutral;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
lines!(ax_mrpk, collect(a_grid), mrpk_averse;
    color=COLOR_CONSTRAINED, linewidth=2)

Legend(fig[2, 1:2],
    [l_rn, l_ra],
    ["Risk-neutral", "Risk-averse (γ = $(GAMMA_RA_LOCAL))"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

save_figure(fig, "fig_07_risk_averse.pdf")
