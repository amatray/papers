# Slide 6: Uncertainty Plus Sunk Costs or Irreversibility
# z shocks + resale loss on downsizing. Bad states destroy net worth.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Random

# ── Simulate: same z shocks, with and without resale loss ───────────

T = 80
z0 = Z_BAR
a0 = a_for_mrpk_ratio(z0, 1.35, R, ALPHA, LAMBDA_LEV, DELTA_K)

# Both firms see the same z sequence (same seed)
reversible = simulate_firm(T=T, z0=z0, a0=a0,
    z_process=:ar1, ρz=RHO_Z, σz=SIGMA_Z,
    zbar=Z_BAR,
    resale_loss=0.0,
    rng=MersenneTwister(SEED))

irreversible = simulate_firm(T=T, z0=z0, a0=a0,
    z_process=:ar1, ρz=RHO_Z, σz=SIGMA_Z,
    zbar=Z_BAR,
    resale_loss=RESALE_LOSS,
    rng=MersenneTwister(SEED))

# Unconstrained K* for reference (same z)
kstar_ref = [k_star(reversible.z[t], R, ALPHA, DELTA_K) for t in 1:T]

# ── Plot ────────────────────────────────────────────────────────────

fig, ax_k, ax_mrpk = create_two_panel_figure()

l_star = lines!(ax_k, 1:T, kstar_ref;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
l_rev = lines!(ax_k, 1:T, reversible.k;
    color=COLOR_THIRD, linewidth=1.8)
l_irr = lines!(ax_k, 1:T, irreversible.k;
    color=COLOR_CONSTRAINED, linewidth=2)

lines!(ax_mrpk, 1:T, fill(user_cost(R, DELTA_K), T);
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)
lines!(ax_mrpk, 1:T, reversible.mrpk;
    color=COLOR_THIRD, linewidth=1.8)
lines!(ax_mrpk, 1:T, irreversible.mrpk;
    color=COLOR_CONSTRAINED, linewidth=2)

ax_k.ylabel = "Capital (K)"
ax_mrpk.ylabel = "MRPK"

Legend(fig[2, 1:2],
    [l_star, l_rev, l_irr],
    ["K* (unconstrained)", "Reversible capital", "With resale loss ($(Int(RESALE_LOSS*100))%)"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=10,
    font=FONT,
)

save_figure(fig, "fig_06_sunk_costs.pdf")
