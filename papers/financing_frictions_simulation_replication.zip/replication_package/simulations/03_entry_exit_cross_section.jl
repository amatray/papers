# Slide 3: Economy-Level Persistence from Entry and Exit
# Deterministic z + entry/exit. New entrants refresh the constrained pool.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Random
using Distributions

const Z_FIXED_DIST = Dirac(Z_BAR)

# ── Simulate two panels: with and without entry/exit ────────────────

panel_no_exit = simulate_panel(
    N=N_FIRMS, T=T_PERIODS,
    z_process=:deterministic, entry_exit=false,
    z_dist=Z_FIXED_DIST,
    seed=SEED,
)

panel_with_exit = simulate_panel(
    N=N_FIRMS, T=T_PERIODS,
    z_process=:deterministic, entry_exit=true,
    δexit=DELTA_EXIT,
    z_dist=Z_FIXED_DIST,
    seed=SEED,
)

share_no_exit   = share_constrained_series(panel_no_exit)
share_with_exit = share_constrained_series(panel_with_exit)

# ── Panel A: firm-level K_t over age (sample of firms from exit panel)

rng = MersenneTwister(SEED + 1)
sample_ids = sort(rand(rng, 1:N_FIRMS, 8))

fig, ax_k, ax_mrpk = create_two_panel_figure()

ax_k.ylabel = "Capital (K)"
ax_k.xlabel = "Period"
ax_mrpk.ylabel = "Share constrained"
ax_mrpk.xlabel = "Period"

for (i, id) in enumerate(sample_ids)
    c = i <= 4 ? COLOR_CONSTRAINED : COLOR_THIRD
    lines!(ax_k, 1:T_PERIODS, panel_with_exit.k[id, :];
        color=(c, 0.5), linewidth=1.2)
end

hlines!(ax_k, [k_star(Z_BAR, R, ALPHA, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

# ── Panel B: Share constrained over time ───────────────────────────

l_no = lines!(ax_mrpk, 1:T_PERIODS, share_no_exit;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
l_ex = lines!(ax_mrpk, 1:T_PERIODS, share_with_exit;
    color=COLOR_CONSTRAINED, linewidth=2)

ylims!(ax_mrpk, 0, 1)

Legend(fig[2, 1:2],
    [l_no, l_ex],
    ["No entry/exit", "With entry/exit"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

save_figure(fig, "fig_03_entry_exit.pdf")
