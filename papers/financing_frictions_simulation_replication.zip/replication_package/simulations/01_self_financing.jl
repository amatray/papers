# Slide 1: Self-Financing Escapes the Trap
# Deterministic z, collateral constraint. Firm saves and converges to K*.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Printf
using Random; Random.seed!(SEED)

# ── Simulate unconstrained and constrained firms ────────────────────

z0 = Z_BAR
kfb = k_star(z0, R, ALPHA, DELTA_K)
afb = (kfb / LAMBDA_LEV) * 1.5  # rich enough to never bind

a0_low = a_for_mrpk_ratio(z0, MRPK_RATIO_LOW, R, ALPHA, LAMBDA_LEV, DELTA_K)
a0_mid = a_for_mrpk_ratio(z0, MRPK_RATIO_MEDIUM, R, ALPHA, LAMBDA_LEV, DELTA_K)

T = 40

unc = simulate_firm(T=T, z0=z0, a0=afb, z_process=:deterministic)
con_low = simulate_firm(T=T, z0=z0, a0=a0_low, z_process=:deterministic)
con_mid = simulate_firm(T=T, z0=z0, a0=a0_mid, z_process=:deterministic)

println("Figure 01 diagnostics:")
println("  alpha = $(ALPHA), z_bar = $(round(Z_BAR, digits=4)), K* = $(round(kfb, digits=3))")
println("  low a0 = $(round(a0_low, digits=3)), initial MRPK/user cost = $(round(con_low.mrpk[1] / user_cost(R, DELTA_K), digits=2)), first unconstrained period = $(something(findfirst(.!con_low.constrained), missing))")
println("  medium a0 = $(round(a0_mid, digits=3)), initial MRPK/user cost = $(round(con_mid.mrpk[1] / user_cost(R, DELTA_K), digits=2)), first unconstrained period = $(something(findfirst(.!con_mid.constrained), missing))")

function first_unconstrained_period(sim)
    p = findfirst(.!sim.constrained)
    return isnothing(p) ? missing : p
end

function write_savings_sensitivity_table(rows, T)
    outdir = joinpath(@__DIR__, "..", "output", "figures")
    mkpath(outdir)
    path = joinpath(outdir, "fig_01b_savings_sensitivity_table.tex")

    open(path, "w") do io
        println(io, "\\begin{adjustbox}{max width=\\linewidth}")
        println(io, "\\begin{tabular}{@{}ccc@{}}")
        println(io, "\\toprule")
        println(io, "\$s\$ & Not retained & Crossing \\\\")
        println(io, "\\midrule")
        for row in rows
            s_str = @sprintf("%.3f", row.s)
            c_str = @sprintf("%.1f\\%%", 100 * (1 - row.s))
            p_str = ismissing(row.period) ? "No crossing by $T" : "Period $(row.period)"
            println(io, "$(s_str) & $(c_str) & $(p_str) \\\\")
        end
        println(io, "\\bottomrule")
        println(io, "\\end{tabular}")
        println(io, "\\end{adjustbox}")
    end

    println("Saved: $(path)")
    return path
end

# ── Plot ────────────────────────────────────────────────────────────

fig, ax_k, ax_mrpk = create_two_panel_figure()

uc_line = lines!(ax_k, 1:T, unc.k;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
cl_line = lines!(ax_k, 1:T, con_low.k;
    color=COLOR_CONSTRAINED, linewidth=2)
cm_line = lines!(ax_k, 1:T, con_mid.k;
    color=COLOR_THIRD, linewidth=2)

lines!(ax_mrpk, 1:T, unc.mrpk;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
lines!(ax_mrpk, 1:T, con_low.mrpk;
    color=COLOR_CONSTRAINED, linewidth=2)
lines!(ax_mrpk, 1:T, con_mid.mrpk;
    color=COLOR_THIRD, linewidth=2)

hlines!(ax_mrpk, [user_cost(R, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

ax_k.ylabel = "Capital (K)"
ax_mrpk.ylabel = "MRPK"

Legend(fig[2, 1:2],
    [uc_line, cm_line, cl_line],
    ["Unconstrained", "Constrained (medium a₀)", "Constrained (low a₀)"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

save_figure(fig, "fig_01_self_financing.pdf")

# ── Retention-rate sensitivity for highly constrained firms ─────────

T_sens = 80
s_grid = [0.775, SAVINGS_RATE, 0.800, 0.875]
sims_s = [
    simulate_firm(T=T_sens, z0=z0, a0=a0_low, z_process=:deterministic, s=s)
    for s in s_grid
]
periods_s = first_unconstrained_period.(sims_s)

println("Figure 01b diagnostics:")
for (s, sim, p) in zip(s_grid, sims_s, periods_s)
    println("  s = $(@sprintf("%.3f", s)), not retained share = $(@sprintf("%.1f", 100*(1-s)))%, first unconstrained period = $(something(p, missing)), final K = $(round(sim.k[end], digits=3))")
end

fig_s = Figure(
    size=(FIGURE_WIDTH, FIGURE_HEIGHT),
    backgroundcolor=:white,
    fontsize=16,
    font=FONT,
)
ax_s_k = Axis(fig_s[1, 1];
    xlabel="Period",
    ylabel="Capital (K)",
    rightspinevisible=false,
    topspinevisible=false,
    xgridvisible=false,
    ygridcolor=GRID_GRAY,
    xlabelcolor=DARK,
    ylabelcolor=DARK,
    xticklabelcolor=DARK,
    yticklabelcolor=DARK,
    xlabelsize=16,
    ylabelsize=16,
    xticklabelsize=13,
    yticklabelsize=13,
)
colors_s = [
    STATA_PALETTE.navy,
    STATA_PALETTE.maroon,
    STATA_PALETTE.sage,
    STATA_PALETTE.eggplant,
]
labels_s = [
    "s=$(@sprintf("%.3f", s))"
    for s in s_grid
]

for (sim, color, label) in zip(sims_s, colors_s, labels_s)
    lines!(ax_s_k, 1:T_sens, sim.k;
        color=color, linewidth=2.8, label=label)
end

hlines!(ax_s_k, [kfb];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

ax_s_k.ylabel = "Capital (K)"
xlims!(ax_s_k, 0, T_sens + 5)
ylims!(ax_s_k, 3.0, 10.85)

label_periods = [60, 30, 14, 1]
label_y = [9.30, 10.34, 10.52, 10.45]
for (color, label, t_label, y_label) in zip(colors_s, labels_s, label_periods, label_y)
    text!(ax_s_k, t_label, y_label;
        text=label,
        color=color,
        fontsize=24,
        font=FONT,
        align=(:left, :center),
    )
end

fig_s_path = save_figure(fig_s, "fig_01b_savings_sensitivity.pdf")

table_rows = [(s=s, period=p) for (s, p) in zip(s_grid, periods_s)]
table_path = write_savings_sensitivity_table(table_rows, T_sens)
