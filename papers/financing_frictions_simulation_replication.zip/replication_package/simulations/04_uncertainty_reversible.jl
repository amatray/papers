# Slide 4: Uncertainty with Reversible Capital
# Idiosyncratic z shocks, capital resold without loss.
# Risk creates episodes of constraint, not necessarily deep persistence.

using Pkg; Pkg.activate(joinpath(@__DIR__, ".."))

include(joinpath(@__DIR__, "..", "params.jl"))
include(joinpath(@__DIR__, "..", "models", "common.jl"))
include(joinpath(@__DIR__, "..", "models", "dynamics.jl"))
using Random

# ── Simulate constrained firm and unconstrained benchmark ───────────

T = 80
z0 = Z_BAR
a0_con = a_for_mrpk_ratio(z0, 1.35, R, ALPHA, LAMBDA_LEV, DELTA_K)

rng_con = MersenneTwister(SEED)  # same z draws for comparison

con = simulate_firm(T=T, z0=z0, a0=a0_con,
    z_process=:ar1, ρz=RHO_Z, σz=SIGMA_Z, zbar=Z_BAR, rng=rng_con)

# Unconstrained benchmark: tracks K*(z_t), so MRPK equals user cost by construction.
kstar_ref = [k_star(con.z[t], R, ALPHA, DELTA_K) for t in 1:T]
mrpk_ref = [mrpk(con.z[t], kstar_ref[t], ALPHA) for t in 1:T]

# ── Plot ────────────────────────────────────────────────────────────

fig, ax_k, ax_mrpk = create_two_panel_figure()

uc_line = lines!(ax_k, 1:T, kstar_ref;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
con_line = lines!(ax_k, 1:T, con.k;
    color=COLOR_CONSTRAINED, linewidth=2)

lines!(ax_mrpk, 1:T, mrpk_ref;
    color=COLOR_UNCONSTRAINED, linewidth=2.5, linestyle=:dash)
lines!(ax_mrpk, 1:T, con.mrpk;
    color=COLOR_CONSTRAINED, linewidth=2)

hlines!(ax_mrpk, [user_cost(R, DELTA_K)];
    color=NOTE_GRAY, linewidth=1, linestyle=:dot)

ax_k.ylabel = "Capital (K)"
ax_mrpk.ylabel = "MRPK"

Legend(fig[2, 1:2],
    [uc_line, con_line],
    ["Unconstrained (K*)", "Constrained"];
    orientation=:horizontal,
    framevisible=false,
    labelcolor=DARK,
    labelsize=11,
    font=FONT,
)

save_figure(fig, "fig_04_uncertainty_reversible.pdf")
