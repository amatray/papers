# Centralized default parameters for financing frictions simulations.
# Per-script overrides: define local constants AFTER including this file.

# Technology
#
# ALPHA is the curvature of a one-factor profit/revenue function after variable
# inputs have been optimized out. It is not the aggregate capital share.
const ALPHA = 0.62
const R = 0.05
const DELTA_K = 0.10
const KSTAR_TARGET = 10.0
const Z_BAR = (R + DELTA_K) * KSTAR_TARGET^(1 - ALPHA) / ALPHA

# Financing friction (Moll/BKS form: k ≤ λ a, with λ ≥ 1 the leverage multiplier)
const LAMBDA_LEV = 2.50
const A_UNCONSTRAINED = KSTAR_TARGET / LAMBDA_LEV

# Savings / retention
const SAVINGS_RATE = 0.782

# Initial conditions used for deterministic teaching examples. These values are
# target MRPK ratios relative to user cost, not arbitrary wealth fractions.
const MRPK_RATIO_LOW = 1.50
const MRPK_RATIO_MEDIUM = 1.20

# Stochastic productivity (Moll-style)
const RHO_Z = 0.90
const SIGMA_Z = 0.12

# Entry/exit (BKS-style)
const DELTA_EXIT = 0.05

# Sunk costs (irreversibility)
const RESALE_LOSS = 0.30

# Risk aversion (BMSS-style)
const GAMMA_RA = 3.0

# Simulation
const N_FIRMS = 500
const T_PERIODS = 100
const SEED = 42
