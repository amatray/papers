using Distributions
using Random
using Statistics

function default_z_dist()
    return LogNormal(log(Z_BAR) - 0.5 * 0.3^2, 0.3)
end

function default_a0_dist()
    return LogNormal(log(A_UNCONSTRAINED * 0.55) - 0.5 * 0.45^2, 0.45)
end

function default_entry_a_dist()
    return LogNormal(log(A_UNCONSTRAINED * 0.20) - 0.5 * 0.30^2, 0.30)
end

# ── Single-firm simulation ──────────────────────────────────────────

function simulate_firm(;
    T::Int,
    z0::Float64,
    a0::Float64,
    α::Float64  = ALPHA,
    r::Float64  = R,
    δk::Float64 = DELTA_K,
    λ::Float64  = LAMBDA_LEV,
    s::Float64  = SAVINGS_RATE,
    z_process::Symbol = :deterministic,
    ρz::Float64 = RHO_Z,
    σz::Float64 = SIGMA_Z,
    zbar::Float64 = Z_BAR,
    resale_loss::Float64 = 0.0,
    rng::AbstractRNG = Random.default_rng(),
)
    z_vec    = zeros(T)
    a_vec    = zeros(T)
    k_vec    = zeros(T)
    mrpk_vec = zeros(T)
    con_vec  = falses(T)

    z_vec[1] = z0
    a_vec[1] = a0

    for t in 1:T
        z = z_vec[t]
        a = a_vec[t]

        kfb  = k_star(z, r, α, δk)
        kcon = constrained_k(a, λ)
        k    = min(kfb, kcon)

        k_vec[t]    = k
        mrpk_vec[t] = mrpk(z, k, α)
        con_vec[t]  = kfb > kcon

        if t < T
            y   = production(z, k, α)
            π   = y - (r + δk) * k
            resources = (1 + r) * a + π

            if resale_loss > 0 && t > 1
                k_prev = k_vec[t-1]
                if k < k_prev
                    resources -= resale_loss * (k_prev - k)
                end
            end

            a_vec[t+1] = max(s * resources, 1e-8)

            if z_process == :deterministic
                z_vec[t+1] = z0
            elseif z_process in (:ar1, :reversible, :irreversible)
                logz_next = log(zbar) + ρz * (log(z) - log(zbar)) + σz * randn(rng)
                z_vec[t+1] = exp(logz_next)
            end
        end
    end

    return (; t=1:T, z=z_vec, a=a_vec, k=k_vec, mrpk=mrpk_vec, constrained=con_vec)
end

# ── Panel simulation (N firms) ──────────────────────────────────────

function simulate_panel(;
    N::Int      = N_FIRMS,
    T::Int      = T_PERIODS,
    α::Float64  = ALPHA,
    r::Float64  = R,
    δk::Float64 = DELTA_K,
    λ::Float64  = LAMBDA_LEV,
    s::Float64  = SAVINGS_RATE,
    z_process::Symbol = :deterministic,
    ρz::Float64 = RHO_Z,
    σz::Float64 = SIGMA_Z,
    zbar::Float64 = Z_BAR,
    resale_loss::Float64 = 0.0,
    entry_exit::Bool = false,
    δexit::Float64   = DELTA_EXIT,
    z_dist = default_z_dist(),
    a0_dist = default_a0_dist(),
    a_entry_dist = nothing,
    seed::Int   = SEED,
)
    rng = MersenneTwister(seed)

    z_init = rand(rng, z_dist, N)
    a_init = rand(rng, a0_dist, N)

    z_panel    = zeros(N, T)
    a_panel    = zeros(N, T)
    k_panel    = zeros(N, T)
    mrpk_panel = zeros(N, T)
    con_panel  = falses(N, T)

    z_panel[:, 1] .= z_init
    a_panel[:, 1] .= a_init

    entry_a = isnothing(a_entry_dist) ? default_entry_a_dist() : a_entry_dist

    for t in 1:T
        for i in 1:N
            z = z_panel[i, t]
            a = a_panel[i, t]

            kfb  = k_star(z, r, α, δk)
            kcon = constrained_k(a, λ)
            k    = min(kfb, kcon)

            k_panel[i, t]    = k
            mrpk_panel[i, t] = mrpk(z, k, α)
            con_panel[i, t]  = kfb > kcon

            if t < T
                y   = production(z, k, α)
                π   = y - (r + δk) * k
                resources = (1 + r) * a + π

                if resale_loss > 0 && t > 1
                    k_prev = k_panel[i, t-1]
                    if k < k_prev
                        resources -= resale_loss * (k_prev - k)
                    end
                end

                exit_draw = entry_exit && rand(rng) < δexit
                a_next = max(s * resources, 1e-8)

                if exit_draw
                    a_next = rand(rng, entry_a)
                end

                a_panel[i, t+1] = a_next

                if z_process == :deterministic
                    z_panel[i, t+1] = exit_draw ? rand(rng, z_dist) : z
                elseif z_process in (:ar1, :reversible, :irreversible)
                    if exit_draw
                        z_panel[i, t+1] = rand(rng, z_dist)
                    else
                        logz_next = log(zbar) + ρz * (log(z) - log(zbar)) + σz * randn(rng)
                        z_panel[i, t+1] = exp(logz_next)
                    end
                end
            end
        end
    end

    return (; z=z_panel, a=a_panel, k=k_panel, mrpk=mrpk_panel, constrained=con_panel)
end

# ── Aggregate statistics ────────────────────────────────────────────

function var_log_mrpk(panel, t::Int)
    m = @view panel.mrpk[:, t]
    logm = log.(max.(m, 1e-10))
    return var(logm)
end

function var_log_mrpk_series(panel)
    T = size(panel.mrpk, 2)
    return [var_log_mrpk(panel, t) for t in 1:T]
end

function share_constrained_series(panel)
    T = size(panel.constrained, 2)
    return [mean(panel.constrained[:, t]) for t in 1:T]
end
