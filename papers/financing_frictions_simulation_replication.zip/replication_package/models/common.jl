using CairoMakie
using Statistics

# ── Economic functions ──────────────────────────────────────────────

production(z, k, α) = z * k^α

mrpk(z, k, α) = α * z * k^(α - 1)

k_star(z, r, α, δk=0.0) = (α * z / (r + δk))^(1 / (1 - α))

constrained_k(a, λ) = λ * a

function k_for_mrpk_ratio(z, ratio, r, α, δk=0.0)
    kfb = k_star(z, r, α, δk)
    return kfb * ratio^(-1 / (1 - α))
end

function a_for_mrpk_ratio(z, ratio, r, α, λ, δk=0.0)
    return k_for_mrpk_ratio(z, ratio, r, α, δk) / λ
end

function actual_k(z, a, r, α, λ, δk=0.0)
    kfb = k_star(z, r, α, δk)
    kcon = constrained_k(a, λ)
    return min(kfb, kcon)
end

function is_constrained(z, a, r, α, λ, δk=0.0)
    return k_star(z, r, α, δk) > constrained_k(a, λ)
end

user_cost(r, δ) = r + δ

# ── Adrien's graph palette (Stata-style, graph-style-universal.md) ──

const STATA_PALETTE = (
    navy     = "#1A476F",
    maroon   = "#90353B",
    sage     = "#6E8E84",
    eggplant = "#6C4675",
    orange   = "#CC6600",
    sand     = "#D9C26399",
)

# Legacy alias retained for archived scripts; use STATA_PALETTE in new edits.
const VIRIDIS = (
    deep_purple  = STATA_PALETTE.navy,
    purple       = STATA_PALETTE.eggplant,
    blue         = STATA_PALETTE.sage,
    teal         = STATA_PALETTE.orange,
    green        = STATA_PALETTE.maroon,
    yellow_green = STATA_PALETTE.sand,
    yellow       = STATA_PALETTE.orange,
)

# Color mapping for all simulation figures.
const COLOR_UNCONSTRAINED = STATA_PALETTE.navy
const COLOR_CONSTRAINED   = STATA_PALETTE.maroon
const COLOR_THIRD         = STATA_PALETTE.sage

const DARK      = "#1A1A1A"
const GRID_GRAY = "#E6E6E6"
const NOTE_GRAY = "#AAAAAA"

# ── Font selection ──────────────────────────────────────────────────

function select_font()
    for f in ["Gill Sans", "Helvetica Neue", "Helvetica", "DejaVu Sans"]
        try
            CairoMakie.to_font(f)
            return f
        catch
        end
    end
    return "sans-serif"
end

const FONT = select_font()

# Sized for the 16:9 beamer deck: the slide's usable figure box
# (textwidth 412.6pt x 0.78*textheight 196.6pt) has ratio ~2.1, so the
# figure is wider than 16:9 to fill the full slide width.
const FIGURE_WIDTH = 960
const FIGURE_HEIGHT = 450

# ── Common two-panel figure (Panel A: K_t, Panel B: MRPK_t) ────────

function create_two_panel_figure(; width=FIGURE_WIDTH, height=FIGURE_HEIGHT)
    fig = Figure(
        size=(width, height),
        backgroundcolor=:white,
        fontsize=13,
        font=FONT,
    )
    ax_k = Axis(fig[1, 1];
        xlabel="Period",
        ylabel="Capital (K)",
        rightspinevisible=false,
        topspinevisible=false,
        xgridvisible=false,
        ygridcolor=GRID_GRAY,
        xlabelcolor=DARK,
        ylabelcolor=DARK,
        xticklabelcolor=DARK,
        yticklabelcolor=DARK,
    )
    ax_mrpk = Axis(fig[1, 2];
        xlabel="Period",
        ylabel="MRPK",
        rightspinevisible=false,
        topspinevisible=false,
        xgridvisible=false,
        ygridcolor=GRID_GRAY,
        xlabelcolor=DARK,
        ylabelcolor=DARK,
        xticklabelcolor=DARK,
        yticklabelcolor=DARK,
    )
    return fig, ax_k, ax_mrpk
end

function add_legend_below!(fig, entries; position=fig[2, 1:2])
    Legend(position, entries...;
        orientation=:horizontal,
        framevisible=false,
        labelcolor=DARK,
        labelsize=12,
        font=FONT,
    )
end

function save_figure(fig, name)
    outdir = joinpath(@__DIR__, "..", "output", "figures")
    mkpath(outdir)
    path = joinpath(outdir, name)
    save(path, fig)
    println("Saved: $path")
    return path
end
