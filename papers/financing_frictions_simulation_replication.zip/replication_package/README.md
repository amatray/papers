# Financing Frictions and Firm Dynamics: Simulation Replication Package

Julia code that reproduces every simulation figure in the lecture
"Financing Frictions and Firm Dynamics" (PhD Corporate Finance,
Lecture 1b). Each script simulates a small partial-equilibrium model of
a firm facing a collateral constraint (k <= lambda * a) and plots the
dynamics of capital and the marginal revenue product of capital (MRPK).

Author: Adrien Matray (adrien.matray@gmail.com)

## Requirements

- [Julia](https://julialang.org/downloads/) 1.10 or later (the package
  versions are pinned under Julia 1.12.6).
- No other software. All Julia packages (CairoMakie, Distributions,
  Random, Statistics) install automatically on first run.

## How to run

From a terminal, in this folder:

```bash
julia run_all.jl
```

The first run downloads and precompiles the plotting stack, which takes
a few minutes. Subsequent runs take well under a minute. All output is
written to `output/figures/`.

To run a single exercise instead, for example the self-financing one:

```bash
julia --project=. simulations/01_self_financing.jl
```

If `Pkg.instantiate()` fails because your Julia version cannot use the
pinned `Manifest.toml`, delete `Manifest.toml` and rerun; Julia will
re-resolve compatible package versions from `Project.toml`.

## What gets produced

| Script | Output | Lecture exercise |
|---|---|---|
| `01_self_financing.jl` | `fig_01_self_financing.pdf`, `fig_01b_savings_sensitivity.pdf`, `fig_01b_savings_sensitivity_table.tex` | Self-financing escapes the constraint: convergence to first-best capital, and how the speed depends on the retention rate |
| `03_entry_exit_cross_section.jl` | `fig_03_entry_exit.pdf` | Entry and exit keep a cross-section of constrained firms alive (Buera, Kaboski, Shin 2011) |
| `04_uncertainty_reversible.jl` | `fig_04_uncertainty_reversible.pdf` | Stochastic productivity with fully reversible capital |
| `05_moll_style_productivity.jl` | `fig_05_moll_productivity.pdf` | Persistent productivity shocks and self-financing (Moll 2014) |
| `06_sunk_costs_irreversibility.jl` | `fig_06_sunk_costs.pdf` | Partial irreversibility: sunk costs create inaction and dispersion |
| `07_risk_averse_entrepreneurs.jl` | `fig_07_risk_averse.pdf` | Risk-averse entrepreneurs under-accumulate (Buera, Majerovitz, Shin, Singh 2024) |
| `08_convex_adjustment_diagnostic.jl` | `fig_08a_convex_only.pdf` | Convex adjustment costs alone: smooth, fast convergence |
| `09_fixed_adjustment_diagnostic.jl` | `fig_08b_fixed_only.pdf` | Fixed adjustment costs alone: lumpy investment |

## Package structure

```
replication_package/
├── run_all.jl            Entry point: runs every script, checks all outputs exist
├── Project.toml          Julia package dependencies
├── Manifest.toml         Exact pinned package versions (Julia 1.12.6)
├── params.jl             All model parameters, shared across scripts
├── models/
│   ├── common.jl         Economic functions (production, MRPK, k*), figure styling
│   ├── dynamics.jl       Simulation engine (wealth accumulation, shock processes)
│   └── paper_specs/      Notes mapping each exercise to its source paper
├── simulations/          One self-contained script per lecture figure
└── output/figures/       Created on first run; all figures land here
```

## Model in one paragraph

A firm with productivity z operates a decreasing-returns technology
z * k^alpha and faces the collateral constraint k <= lambda * a, where a
is entrepreneur wealth. Constrained firms have MRPK above the user cost
r + delta; retained earnings relax the constraint over time. The scripts
vary one ingredient at a time (deterministic vs. stochastic z, entry and
exit, irreversibility, risk aversion, adjustment costs) to show which
frictions self-financing can and cannot undo. Parameter values and their
calibration logic are documented in `params.jl`.
