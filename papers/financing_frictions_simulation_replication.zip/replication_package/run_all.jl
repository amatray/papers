# Reproduce all simulation figures from Lecture 1b: Financing Frictions
# and Firm Dynamics.
#
# Usage:   julia run_all.jl
# Output:  output/figures/  (9 PDF figures + 1 LaTeX table fragment)
#
# The first run installs the pinned Julia packages and precompiles
# CairoMakie, which can take several minutes. Later runs are fast.

using Pkg
Pkg.activate(@__DIR__)
Pkg.instantiate()

const SCRIPTS = [
    "01_self_financing.jl",                # fig_01, fig_01b + sensitivity table
    "03_entry_exit_cross_section.jl",      # fig_03
    "04_uncertainty_reversible.jl",        # fig_04
    "05_moll_style_productivity.jl",       # fig_05
    "06_sunk_costs_irreversibility.jl",    # fig_06
    "07_risk_averse_entrepreneurs.jl",     # fig_07
    "08_convex_adjustment_diagnostic.jl",  # fig_08a
    "09_fixed_adjustment_diagnostic.jl",   # fig_08b
]

const EXPECTED = [
    "fig_01_self_financing.pdf",
    "fig_01b_savings_sensitivity.pdf",
    "fig_01b_savings_sensitivity_table.tex",
    "fig_03_entry_exit.pdf",
    "fig_04_uncertainty_reversible.pdf",
    "fig_05_moll_productivity.pdf",
    "fig_06_sunk_costs.pdf",
    "fig_07_risk_averse.pdf",
    "fig_08a_convex_only.pdf",
    "fig_08b_fixed_only.pdf",
]

for script in SCRIPTS
    println("\n=== Running $(script) ===")
    run(`$(Base.julia_cmd()) --project=$(@__DIR__) $(joinpath(@__DIR__, "simulations", script))`)
end

outdir = joinpath(@__DIR__, "output", "figures")
missing_files = filter(f -> !isfile(joinpath(outdir, f)), EXPECTED)
if isempty(missing_files)
    println("\nAll $(length(EXPECTED)) lecture outputs written to $(outdir).")
else
    error("Missing expected outputs: " * join(missing_files, ", "))
end
